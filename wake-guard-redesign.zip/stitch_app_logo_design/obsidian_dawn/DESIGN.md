---
name: Obsidian Dawn
colors:
  surface: '#10141a'
  surface-dim: '#10141a'
  surface-bright: '#353940'
  surface-container-lowest: '#0a0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#dfe2eb'
  on-surface-variant: '#dac1b9'
  inverse-surface: '#dfe2eb'
  inverse-on-surface: '#2d3137'
  outline: '#a28c85'
  outline-variant: '#54433d'
  surface-tint: '#ffb59a'
  primary: '#ffc5b1'
  on-primary: '#591d02'
  primary-container: '#ff9e79'
  on-primary-container: '#783316'
  inverse-primary: '#94492a'
  secondary: '#dcfdff'
  on-secondary: '#00373a'
  secondary-container: '#00f1fd'
  on-secondary-container: '#006a6f'
  tertiary: '#ffc6a7'
  on-tertiary: '#532200'
  tertiary-container: '#ff9f66'
  on-tertiary-container: '#773400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#763216'
  secondary-fixed: '#6ff6ff'
  secondary-fixed-dim: '#00dce6'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#ffdbc9'
  tertiary-fixed-dim: '#ffb68d'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#10141a'
  on-background: '#dfe2eb'
  surface-variant: '#31353c'
typography:
  display-time:
    fontFamily: Plus Jakarta Sans
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 76px
    letterSpacing: -0.04em
  display-time-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system establishes a high-vigilance, fail-safe environment for mission-critical morning routines. Built around the tension between nocturnal calm and kinetic morning activation, the interface guides groggy users from low cognitive arousal to active alertness.

The aesthetic fuses modern OS precision with vibrant tactical accents. Grounded in obsidian and slate dark tiers, the interface prioritizes glanceability, high-contrast touch zones, and immediate legibility in zero-light settings. Warm coral provides a soft, unaggressive dawn luminescence for standard CTAs, paired with high-voltage electric cyan and radiant amber for dynamic challenge states, progress arcs, and cognitive milestones. The physical shape language leans on oversized pill silhouettes, eliminating tap hesitation under groggy motor control.

## Colors

The palette balances eye comfort in total darkness with unmistakable daytime activation signals.

- **Primary (`#FF9E79`)**: Warm coral/sunrise peach. Used for primary execution actions, primary progress meters, and dominant confirmations. Always pairs with deep charcoal (`#121418`) typography to guarantee high contrast without eye strain.
- **Secondary (`#00F2FE`)**: Electric cyan. Used for biometric confirmation, QR scanners, cognitive puzzle tracking, and active toggles.
- **Tertiary (`#FF8C42`)**: Alert amber. Used for impending alarm timeouts, wake-up streaks, countdown gauges, and urgency flags.
- **Neutral Backgrounds**: Built on deep obsidian tiers—`#0D1117` (Canvas base), `#161B22` (Surface card/container), and `#21262D` (Elevated modals, bottom sheets, floating navigation controls).
- **Text & Feedback**: High-contrast white (`#F0F6FC`) for primary titles, muted titanium (`#8B949E`) for secondary labels and challenge details, and vibrant red (`#FF453A`) reserved strictly for catastrophic alarm failures or emergency bypasses.

## Typography

The typography pairs geometric presence with utilitarian clarity.

- **Headlines & Digital Clockfaces (`Plus Jakarta Sans`)**: Delivers friendly, modern authority. The rounded geometric terminals feel inviting rather than clinical. Large digital time readouts feature negative tracking to keep hours and minutes visually unified.
- **Body & Challenges (`Inter`)**: Serves as the functional engine for challenge instructions, settings, math operands, and status badges. The tall x-height and neutral geometry ensure split-second comprehension when users are shaking off sleep inertia.
- **Tabular Figures**: All clock readouts, countdown timers, and challenge scoreboards enforce tabular numbers (`tnum`) to prevent jittering during active updates.

## Layout & Spacing

The layout is built for single-handed mobile thumb reaches with zero-clutter margins.

- **Grid Architecture**: Single-column fluid framework on mobile screens bounded by `1.25rem` (`20px`) outer margins. Multi-column cards (such as 2x2 wake challenge grids) maintain a strict `1rem` (`16px`) gutter.
- **Touch Ergonomics**: All interactive alarm actions maintain a minimum touch target of `56px` height. Primary dismissal and challenge action buttons sit anchored in the bottom thumb zone, while clock visualizers occupy the upper two-thirds.
- **Rhythm**: Compact gaps (`space-xs` to `space-sm`) group related metadata (e.g., repeating day chips next to alarm titles), while generous vertical gaps (`space-xl` to `space-2xl`) isolate separate functional cards to avoid mis-taps.

## Elevation & Depth

Visual hierarchy avoids heavy drop shadows, instead using disciplined surface luminance and tinted perimeter outlines.

- **Canvas Base (`#0D1117`)**: The lowest plane, pure ambient darkness.
- **Surface Level 1 (`#161B22`)**: Standard cards, alarm list items, and inactive challenge pods. Finished with a subtle ghost border (`1px solid rgba(255, 255, 255, 0.08)`).
- **Surface Level 2 (`#21262D`)**: Interactive bottom sheets, modal math challenge overlays, and active numpads. Elevated with a soft ambient shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.65)`.
- **Active Glows**: Engaged states (like an active alarm or a successfully solved puzzle) cast subtle chromatic glows rather than standard black shadows:
  - Coral CTA: `0 8px 24px -2px rgba(255, 158, 121, 0.25)`
  - Electric Cyan: `0 8px 24px -2px rgba(0, 242, 254, 0.2)`

## Shapes

The interface embraces full pill shapes (`roundedness: 3`) across all action-driven surfaces, balanced by structured rounded rectangles on outer containment shells.

- **Pills (`rounded-full` / `9999px`)**: Standard for all action buttons (finish practice, snooze, dismiss), status chips, input tags, and segmented day selectors.
- **Cards & Modals**: Outer card containers use `1.5rem` (`24px`) corner radii, nesting pill elements neatly inside without corner collision.
- **Input Fields & Keypads**: Challenge keypads and code inputs use `1rem` to `1.25rem` roundedness to provide large, tactile target areas.

## Components

### Buttons
- **Primary Action (Sunrise Pill)**: Full-bleed pill container filled with warm coral (`#FF9E79`). Typography is set to `label-lg` in dark charcoal (`#121418`) with medium weight. Minimum height `56px`. Ambient peach glow on press.
- **Secondary Action (Subtle Pill)**: Transparent or surface-tinted pill (`rgba(255, 255, 255, 0.08)`) with white text (`#F0F6FC`) and a 1px ghost border.
- **Emergency / Destructive Button**: Outlined pill in alert crimson with muted text for emergency dismiss.

### Challenge Tiles & Cards
- **Challenge Selectors (Math, Memory, QR, Shake)**: Grid modules built on `#161B22` with a `1.5rem` radius. Icons glow with dedicated functional accents (Electric Cyan for QR/Shake, Alert Amber for Math/Memory). When selected, the border transitions from faint gray to `#00F2FE` with a faint interior gradient.

### Chips & Day Badges
- **Weekday Pills**: Compact pill indicators (`32px` diameter or pill width). Inactive days render as `#21262D` with `#8B949E` text; active alarm days light up with solid primary coral or cyan with dark text.

### Alarm List Item
- Stacked card with a large `36px` time display (`Plus Jakarta Sans`), alarm label below in `body-sm`, and an oversized pill switch on the right side. Smooth background shift on toggle.

### Inputs & Keypads
- Math challenge and numpad inputs are built with high-legibility sans-serif numbers, encased in floating pill or high-radius blocks (`#21262D`) that visually compress on tap with tactile haptic feedback.